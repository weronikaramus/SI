<?php declare(strict_types=1);
/**
 * Debug settings.
 *
 * @link https://epi.chojna.info.pl
 * @author EPI UJ <epi@uj.edu.pl>
 * @copyright (c) 2017-2022
 */
error_reporting(E_ALL);
ini_set('display_errors', '1');